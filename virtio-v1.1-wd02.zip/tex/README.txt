This is one component of a Work Product that also includes:

    Abstract: abstract.tex
    Introduction: introduction.tex
    Main specification content: content.tex
    Conformance targets and clauses: conformance.tex
    Acknowledgements: acknowledgements.tex
    TeX source ﬁles for generating output in pdf and html format.
