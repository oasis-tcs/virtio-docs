be32 {
	vqn : 16;
	next_off : 15;
	next_wrap : 1;
};
